import express, { Express } from "express";
import cors from "cors";
import cookieParser from "cookie-parser";

import dotenv from 'dotenv';
dotenv.config();

const app: Express = express();

const PORT: number = Number(process.env.PORT) || 3214;
const URL: string = process.env.BACKEND_URL || `http://localhost:${PORT}`;


app.use(cors({
  origin: ['https://your-url-with-domain.com', '*'],
  credentials: true,
  allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(cookieParser());
app.use(express.json());
app.get('/', (req, res) => {
  res.send('welcome to base app number four');
});

const startServer = async () => {
  try {
    app.listen(PORT, '0.0.0.0', () => {
      console.log(`Server running on ${URL}`);
    });
  } catch (error) {
    console.error('Database connection failed:', error);
    process.exit(1);
  }
};

startServer();

export default app;